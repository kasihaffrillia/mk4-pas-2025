package com.kasih.beaulivre

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class BukuCanvasPage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_buku_canvas_page)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Tombol chapter (bab)
        findViewById<Button>(R.id.btn_bab_1).setOnClickListener {
            startActivity(Intent(this, Bab1Canvas::class.java))
        }
        findViewById<Button>(R.id.btn_bab_2).setOnClickListener {
            startActivity(Intent(this, Bab2Canvas::class.java))
        }
        findViewById<Button>(R.id.btn_bab_3).setOnClickListener {
            startActivity(Intent(this, Bab3Canvas::class.java))
        }
        findViewById<Button>(R.id.btn_bab_4).setOnClickListener {
            startActivity(Intent(this, Bab4Canvas::class.java))
        }
        findViewById<Button>(R.id.btn_bab_5).setOnClickListener {
            startActivity(Intent(this, Bab5Canvas::class.java))
        }
        findViewById<Button>(R.id.btn_bab_6).setOnClickListener {
            startActivity(Intent(this, Bab6Canvas::class.java))
        }
        findViewById<Button>(R.id.btn_bab_7).setOnClickListener {
            startActivity(Intent(this, Bab7Canvas::class.java))
        }
        findViewById<Button>(R.id.btn_bab_8).setOnClickListener {
            startActivity(Intent(this, Bab8Canvas::class.java))
        }

        // Tombol Mulai Membaca (ke Bab1)
        findViewById<Button>(R.id.btn_mulai_membaca).setOnClickListener {
            startActivity(Intent(this, Bab1Canvas::class.java))
        }

        // Bottom navigation setup
        setupBottomNavigation()
    }

    private fun setupBottomNavigation() {
        val navHome = findViewById<ImageView>(R.id.nav_home)
        val navDraft = findViewById<ImageView>(R.id.nav_draft)
        val navWrite = findViewById<ImageView>(R.id.nav_write)
        val navProfile = findViewById<ImageView>(R.id.nav_profile)
        val navSearch = findViewById<ImageView>(R.id.nav_search)

        navHome.setOnClickListener {
            startActivity(Intent(this, HomePage::class.java))
            finish()
        }
        navDraft.setOnClickListener {
            startActivity(Intent(this, FavoritPage::class.java))
            finish()
        }
        navWrite.setOnClickListener {
            startActivity(Intent(this, RequestListActivity::class.java))
            finish()
        }
        navProfile.setOnClickListener {
            startActivity(Intent(this, ProfilePage::class.java))
            finish()
        }
        navSearch.setOnClickListener {
            startActivity(Intent(this, Telusuri1page::class.java))
            finish()
        }
    }
}
