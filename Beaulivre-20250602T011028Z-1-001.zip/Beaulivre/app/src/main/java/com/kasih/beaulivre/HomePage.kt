package com.kasih.beaulivre

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class HomePage : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home_page)

        // Set up edge-to-edge display
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Set up images click actions (navigate to book pages)
        setupBookImageClicks()

        // Bottom navigation setup
        setupBottomNavigation()
    }

    private fun setupBookImageClicks() {
        // Get all the book images
        val imageView1 = findViewById<ImageView>(R.id.imageView1)
        val imageView2 = findViewById<ImageView>(R.id.imageView2)
        val imageView3 = findViewById<ImageView>(R.id.imageView3)
        val imageView4 = findViewById<ImageView>(R.id.imageView4)

        // Set onClickListeners to navigate to the corresponding book page
        imageView1.setOnClickListener {
            startActivity(Intent(this, BukuAlicePage::class.java)) // Navigate to BukuDiePage
        }

        imageView2.setOnClickListener {
            startActivity(Intent(this, BukuPennyPage::class.java)) // Navigate to BukuPennyPage
        }

        imageView3.setOnClickListener {
            startActivity(Intent(this, BukuCanvasPage::class.java)) // Navigate to BukuCanvasPage
        }

        imageView4.setOnClickListener {
            startActivity(Intent(this, BukuDiePage::class.java)) // Navigate to BukuAlicePage
        }
    }

    private fun setupBottomNavigation() {
        // Get the bottom navigation buttons
        val navHome = findViewById<ImageView>(R.id.nav_home)
        val navDraft = findViewById<ImageView>(R.id.nav_draft)
        val navWrite = findViewById<ImageView>(R.id.nav_write)
        val navProfile = findViewById<ImageView>(R.id.nav_profile)
        val navSearch = findViewById<ImageView>(R.id.nav_search)

        // Home button click
        navHome.setOnClickListener {
            startActivity(Intent(this, HomePage::class.java))
            finish()
        }

        // Draft button click
        navDraft.setOnClickListener {
            startActivity(Intent(this, FavoritPage::class.java))
            finish()
        }

        // Write button click
        navWrite.setOnClickListener {
            startActivity(Intent(this, RequestListActivity::class.java))
            finish()
        }

        // Profile button click
        navProfile.setOnClickListener {
            startActivity(Intent(this, ProfilePage::class.java))
            finish()
        }

        // Search button click
        navSearch.setOnClickListener {
            startActivity(Intent(this, Telusuri1page::class.java))
            finish()
        }
    }
}
