package com.kasih.beaulivre

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Bab1Alice : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_bab1_alice)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Tombol Back
        val btnBack: ImageButton = findViewById(R.id.btn_back)
        btnBack.setOnClickListener {
            // Misal balik ke BukuAlicePage
            startActivity(Intent(this, BukuAlicePage::class.java))
            finish()
        }

        // Tombol Next
        val btnNext: Button = findViewById(R.id.btn_next)
        btnNext.setOnClickListener {
            // Misal ke Bab2Alice
            startActivity(Intent(this, Bab2Alice::class.java))
            finish()
        }

        // Bottom Navigation
        val navHome: ImageView = findViewById(R.id.nav_home)
        val navDraft: ImageView = findViewById(R.id.nav_draft)
        val navWrite: ImageView = findViewById(R.id.nav_write)
        val navProfile: ImageView = findViewById(R.id.nav_profile)
        val navSearch: ImageView = findViewById(R.id.nav_search)

        navHome.setOnClickListener {
            startActivity(Intent(this, HomePage::class.java))
            finish()
        }
        navDraft.setOnClickListener {
            startActivity(Intent(this, FavoritPage::class.java))
            finish()
        }
        navWrite.setOnClickListener {
            startActivity(Intent(this, RequestListActivity::class.java))
            finish()
        }
        navProfile.setOnClickListener {
            startActivity(Intent(this, ProfilePage::class.java))
            finish()
        }
        navSearch.setOnClickListener {
            startActivity(Intent(this, Telusuri1page::class.java))
            finish()
        }
    }
}
