package com.kasih.beaulivre

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.cardview.widget.CardView

class FavoritPage : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_favorit_page)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Card Views for Books
        val cardView1: CardView = findViewById(R.id.card_view_1)
        val cardView2: CardView = findViewById(R.id.card_view_2)
        val cardView3: CardView = findViewById(R.id.card_view_3)

        // Handle card clicks and redirect to respective book pages
        cardView1.setOnClickListener {
            startActivity(Intent(this, BukuAlicePage::class.java)) // Redirect to Buku Alice Page
        }

        cardView2.setOnClickListener {
            startActivity(Intent(this, BukuCanvasPage::class.java)) // Redirect to Buku Canvas Page
        }

        cardView3.setOnClickListener {
            startActivity(Intent(this, BukuPennyPage::class.java)) // Redirect to Buku Die Page
        }

        // Bottom Navigation Setup
        setupBottomNavigation()
    }

    private fun setupBottomNavigation() {
        val navHome: ImageView = findViewById(R.id.nav_home)
        val navDraft: ImageView = findViewById(R.id.nav_draft)
        val navWrite: ImageView = findViewById(R.id.nav_write)
        val navProfile: ImageView = findViewById(R.id.nav_profile)
        val navSearch: ImageView = findViewById(R.id.nav_search)

        navHome.setOnClickListener {
            startActivity(Intent(this, HomePage::class.java)) // Navigate to Home Page
            finish()
        }

        navDraft.setOnClickListener {
            startActivity(Intent(this, FavoritPage::class.java)) // Navigate to FavoritPage
            finish()
        }

        navWrite.setOnClickListener {
            startActivity(Intent(this, RequestListActivity::class.java)) // Navigate to Write Page
            finish()
        }

        navProfile.setOnClickListener {
            startActivity(Intent(this, ProfilePage::class.java)) // Navigate to Profile Page
            finish()
        }

        navSearch.setOnClickListener {
            startActivity(Intent(this, Telusuri1page::class.java)) // Navigate to Search Page
            finish()
        }
    }
}
