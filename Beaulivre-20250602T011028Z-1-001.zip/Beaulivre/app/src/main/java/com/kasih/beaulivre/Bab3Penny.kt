package com.kasih.beaulivre

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Bab3Penny : AppCompatActivity() {
    private lateinit var btnBack: ImageButton
    private lateinit var btnNext: Button
    private lateinit var navHome: ImageView
    private lateinit var navDraft: ImageView
    private lateinit var navWrite: ImageView
    private lateinit var navProfile: ImageView
    private lateinit var navSearch: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_bab3_penny)

        // Set up edge-to-edge display
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initializing UI components
        btnBack = findViewById(R.id.btn_back)
        btnNext = findViewById(R.id.btn_next)
        navHome = findViewById(R.id.nav_home)
        navDraft = findViewById(R.id.nav_draft)
        navWrite = findViewById(R.id.nav_write)
        navProfile = findViewById(R.id.nav_profile)
        navSearch = findViewById(R.id.nav_search)

        // Back button functionality: Navigate to previous chapter (Bab2Penny)
        btnBack.setOnClickListener {
            startActivity(Intent(this, Bab2Penny::class.java))
            finish()
        }

        // Next button functionality: Navigate to next chapter (Bab4Penny)
        btnNext.setOnClickListener {
            startActivity(Intent(this, Bab4Penny::class.java))
            finish()
        }

        // Bottom navigation setup
        setupBottomNavigation()
    }

    private fun setupBottomNavigation() {
        // Bottom navigation actions for Home, Draft, Write, Profile, Search
        navHome.setOnClickListener {
            startActivity(Intent(this, HomePage::class.java))
            finish()
        }
        navDraft.setOnClickListener {
            startActivity(Intent(this, FavoritPage::class.java))
            finish()
        }
        navWrite.setOnClickListener {
            startActivity(Intent(this, RequestListActivity::class.java))
            finish()
        }
        navProfile.setOnClickListener {
            startActivity(Intent(this, ProfilePage::class.java))
            finish()
        }
        navSearch.setOnClickListener {
            startActivity(Intent(this, Telusuri1page::class.java))
            finish()
        }
    }
}
