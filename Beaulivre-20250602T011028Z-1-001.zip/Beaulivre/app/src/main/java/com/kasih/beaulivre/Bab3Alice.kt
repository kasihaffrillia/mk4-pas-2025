package com.kasih.beaulivre

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView

class Bab3Alice : AppCompatActivity() {

    private lateinit var btnBack: ImageButton
    private lateinit var btnNext: Button
    private lateinit var navHome: ImageView
    private lateinit var navDraft: ImageView
    private lateinit var navWrite: ImageView
    private lateinit var navProfile: ImageView
    private lateinit var navSearch: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_bab3_alice)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Inisialisasi tombol dan navigasi
        btnBack = findViewById(R.id.btn_back)
        btnNext = findViewById(R.id.btn_next)
        navHome = findViewById(R.id.nav_home)
        navDraft = findViewById(R.id.nav_draft)
        navWrite = findViewById(R.id.nav_write)
        navProfile = findViewById(R.id.nav_profile)
        navSearch = findViewById(R.id.nav_search)

        // Intent untuk tombol back (kembali ke Bab2Alice)
        btnBack.setOnClickListener {
            startActivity(Intent(this, Bab2Alice::class.java))
            finish()
        }

        // Intent untuk tombol next (lanjut ke Bab4Alice misalnya)
        btnNext.setOnClickListener {
            startActivity(Intent(this, Bab4Alice::class.java))
            finish()
        }

        // Bottom Navigation intents
        navHome.setOnClickListener {
            startActivity(Intent(this, HomePage::class.java))
            finish()
        }
        navDraft.setOnClickListener {
            startActivity(Intent(this, FavoritPage::class.java))
            finish()
        }
        navWrite.setOnClickListener {
            startActivity(Intent(this, RequestListActivity::class.java))
            finish()
        }
        navProfile.setOnClickListener {
            startActivity(Intent(this, ProfilePage::class.java))
            finish()
        }
        navSearch.setOnClickListener {
            startActivity(Intent(this, Telusuri1page::class.java))
            finish()
        }
    }
}
