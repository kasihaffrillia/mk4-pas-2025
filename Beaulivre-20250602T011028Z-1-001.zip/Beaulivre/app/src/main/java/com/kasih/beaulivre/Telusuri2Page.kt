package com.kasih.beaulivre

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Telusuri2Page : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_telusuri2_page)

        // Set up the UI when the page is created
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Setting up category images click logic
        setupCategoryImages()

        // Bottom Navigation Setup
        setupBottomNavigation()
    }

    private fun setupCategoryImages() {


        // Click listener for the first image (for example, Fantasi category)
        findViewById<ImageView>(R.id.imageView2).setOnClickListener {
            // Navigate directly to the specific book page or category page for "Fantasi"
            startActivity(Intent(this, BukuDiePage::class.java)) // Replace with the actual activity for Fantasi
        }

        // Click listener for the second image
        findViewById<ImageView>(R.id.imageView4).setOnClickListener {
            // Navigate directly to the Canvas category
            startActivity(Intent(this, BukuCanvasPage::class.java)) // Replace with the actual activity for Canvas
        }

        // Click listener for the third image
        findViewById<ImageView>(R.id.imageView5).setOnClickListener {
            // Navigate directly to the third category or book
            startActivity(Intent(this, BukuPennyPage::class.java)) // Adjust to the desired book page or category
        }

        // Click listener for the fourth image
        findViewById<ImageView>(R.id.imageView6).setOnClickListener {
            // Navigate directly to the fourth category or book
            startActivity(Intent(this, BukuAlicePage::class.java)) // Adjust accordingly
        }
    }

    private fun setupBottomNavigation() {
        // Bottom Navigation - Set up onClickListeners for each button
        findViewById<ImageView>(R.id.nav_home).setOnClickListener {
            startActivity(Intent(this, HomePage::class.java))
            finish()
        }

        findViewById<ImageView>(R.id.nav_draft).setOnClickListener {
            startActivity(Intent(this, FavoritPage::class.java))
            finish()
        }

        findViewById<ImageView>(R.id.nav_write).setOnClickListener {
            startActivity(Intent(this, RequestListActivity::class.java))
            finish()
        }

        findViewById<ImageView>(R.id.nav_profile).setOnClickListener {
            startActivity(Intent(this, ProfilePage::class.java))
            finish()
        }

        findViewById<ImageView>(R.id.nav_search).setOnClickListener {
            startActivity(Intent(this, Telusuri1page::class.java))
            finish()
        }
    }
}
