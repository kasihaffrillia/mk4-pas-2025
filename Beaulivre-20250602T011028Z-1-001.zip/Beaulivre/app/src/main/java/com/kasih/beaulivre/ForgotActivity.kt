package com.kasih.beaulivre

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.util.Patterns
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class ForgotActivity : AppCompatActivity() {

    private lateinit var emailEditText: EditText
    private lateinit var sendButton: Button
    private lateinit var alertTextView: TextView
    private lateinit var backToLoginLink: TextView

    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_forgot)

        // Initialize Firebase Auth
        firebaseAuth = FirebaseAuth.getInstance()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize views
        emailEditText = findViewById(R.id.etEmail)
        sendButton = findViewById(R.id.btnSend)
        alertTextView = findViewById(R.id.tvAlert)
        backToLoginLink = findViewById(R.id.tvBackToLogin)

        // Handle send button click
        sendButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()

            if (validateEmail(email)) {
                // Show alert box after sending reset link
                alertTextView.visibility = TextView.VISIBLE

                // Send reset password email using Firebase
                sendResetPasswordEmail(email)
            }
        }

        // Handle back to login link click
        backToLoginLink.setOnClickListener {
            startActivity(Intent(this, LoginPage::class.java))  // Replace with actual LoginActivity
            finish()
        }
    }

    // Email validation method
    private fun validateEmail(email: String): Boolean {
        return if (email.isEmpty()) {
            emailEditText.error = "Email tidak boleh kosong"
            false
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailEditText.error = "Masukkan email yang valid"
            false
        } else {
            true
        }
    }

    // Method to send password reset email using Firebase Authentication
    private fun sendResetPasswordEmail(email: String) {
        firebaseAuth.sendPasswordResetEmail(email)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this, "Tautan reset kata sandi telah dikirim ke email Anda.", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Gagal mengirim email reset kata sandi.", Toast.LENGTH_SHORT).show()
                }
            }
    }
}
