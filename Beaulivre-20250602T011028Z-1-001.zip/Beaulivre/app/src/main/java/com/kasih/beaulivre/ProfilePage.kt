package com.kasih.beaulivre

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class ProfilePage : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var nameEditText: EditText
    private lateinit var phoneEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var btnLogout: Button
    private lateinit var btnSave: Button
    private lateinit var navHome: ImageView
    private lateinit var navDraft: ImageView
    private lateinit var navWrite: ImageView
    private lateinit var navProfile: ImageView
    private lateinit var navSearch: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_profile_page)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize views
        nameEditText = findViewById(R.id.editTextText)
        phoneEditText = findViewById(R.id.editTextPhone)
        emailEditText = findViewById(R.id.editTextTextEmailAddress)
        btnLogout = findViewById(R.id.buttonlogout)
        btnSave = findViewById(R.id.buttonsave)
        navHome = findViewById(R.id.nav_home)
        navDraft = findViewById(R.id.nav_draft)
        navWrite = findViewById(R.id.nav_write)
        navProfile = findViewById(R.id.nav_profile)
        navSearch = findViewById(R.id.nav_search)

        // Initialize SharedPreferences for saving user data
        sharedPreferences = getSharedPreferences("UserProfile", MODE_PRIVATE)

        // Load saved user data if available
        loadUserData()

        // Save user data when Save button is clicked
        btnSave.setOnClickListener {
            saveUserData()
        }

        // Handle Logout functionality
        btnLogout.setOnClickListener {
            logout()
        }

        // Bottom Navigation Setup
        setupBottomNavigation()
    }

    private fun loadUserData() {
        val name = sharedPreferences.getString("name", "")
        val phone = sharedPreferences.getString("phone", "")
        val email = sharedPreferences.getString("email", "")

        // Set the user data in the input fields
        nameEditText.setText(name)
        phoneEditText.setText(phone)
        emailEditText.setText(email)
    }

    private fun saveUserData() {
        // Get the user input values
        val name = nameEditText.text.toString()
        val phone = phoneEditText.text.toString()
        val email = emailEditText.text.toString()

        // Save the data in SharedPreferences
        val editor = sharedPreferences.edit()
        editor.putString("name", name)
        editor.putString("phone", phone)
        editor.putString("email", email)
        val success = editor.commit() // commit is synchronous and ensures that data is saved before proceeding

        if (success) {
            Toast.makeText(this, "Data saved successfully!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Error saving data.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun logout() {
        // Clear saved user data on logout
        val editor = sharedPreferences.edit()
        editor.clear()
        editor.apply()

        // Redirect to Login page (replace with your actual login page activity)
        startActivity(Intent(this, LoginPage::class.java))
        finish()
    }

    private fun setupBottomNavigation() {
        // Bottom Navigation - Set up onClickListeners for each button
        navHome.setOnClickListener {
            startActivity(Intent(this, HomePage::class.java))
            finish()
        }
        navDraft.setOnClickListener {
            startActivity(Intent(this, FavoritPage::class.java))
            finish()
        }
        navWrite.setOnClickListener {
            startActivity(Intent(this, RequestListActivity::class.java))
            finish()
        }
        navProfile.setOnClickListener {
            startActivity(Intent(this, ProfilePage::class.java))
            finish()
        }
        navSearch.setOnClickListener {
            startActivity(Intent(this, Telusuri1page::class.java))
            finish()
        }
    }
}
