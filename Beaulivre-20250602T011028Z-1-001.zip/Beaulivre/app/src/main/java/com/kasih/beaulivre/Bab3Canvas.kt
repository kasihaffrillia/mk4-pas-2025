package com.kasih.beaulivre

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Bab3Canvas : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_bab3_canvas)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Tombol Back kembali ke BukuCanvasPage atau Bab2Canvas (sesuaikan)
        findViewById<ImageButton>(R.id.btn_back).setOnClickListener {
            startActivity(Intent(this, Bab2Canvas::class.java))
            finish()
        }

        // Tombol Next menuju Bab4Canvas (buat kelas dan layout Bab4Canvas juga)
        findViewById<Button>(R.id.btn_next).setOnClickListener {
            startActivity(Intent(this, Bab4Canvas::class.java))
            finish()
        }

        // Bottom navigation
        setupBottomNavigation()
    }

    private fun setupBottomNavigation() {
        val navHome = findViewById<ImageView>(R.id.nav_home)
        val navDraft = findViewById<ImageView>(R.id.nav_draft)
        val navWrite = findViewById<ImageView>(R.id.nav_write)
        val navProfile = findViewById<ImageView>(R.id.nav_profile)
        val navSearch = findViewById<ImageView>(R.id.nav_search)

        navHome.setOnClickListener {
            startActivity(Intent(this, HomePage::class.java))
            finish()
        }
        navDraft.setOnClickListener {
            startActivity(Intent(this, FavoritPage::class.java))
            finish()
        }
        navWrite.setOnClickListener {
            startActivity(Intent(this, RequestListActivity::class.java))
            finish()
        }
        navProfile.setOnClickListener {
            startActivity(Intent(this, ProfilePage::class.java))
            finish()
        }
        navSearch.setOnClickListener {
            startActivity(Intent(this, Telusuri1page::class.java))
            finish()
        }
    }
}
