package com.kasih.beaulivre

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Bab2Penny : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_bab2_penny)

        // Set up edge-to-edge display
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Back Button (Navigating back to BukuPennyPage)
        findViewById<ImageButton>(R.id.btn_back).setOnClickListener {
            startActivity(Intent(this, Bab1Penny::class.java)) // Go back to BukuPennyPage
            finish() // Finish current activity to remove it from the stack
        }

        // Next Button (Navigating to Bab 3)
        findViewById<Button>(R.id.btn_next).setOnClickListener {
            startActivity(Intent(this, Bab3Penny::class.java)) // Navigate to Bab 3
            finish() // Finish current activity
        }

        // Bottom Navigation setup
        setupBottomNavigation()
    }

    private fun setupBottomNavigation() {
        val navHome = findViewById<ImageView>(R.id.nav_home)
        val navDraft = findViewById<ImageView>(R.id.nav_draft)
        val navWrite = findViewById<ImageView>(R.id.nav_write)
        val navProfile = findViewById<ImageView>(R.id.nav_profile)
        val navSearch = findViewById<ImageView>(R.id.nav_search)

        navHome.setOnClickListener {
            startActivity(Intent(this, HomePage::class.java)) // Navigate to HomePage
            finish() // Finish current activity
        }

        navDraft.setOnClickListener {
            startActivity(Intent(this, FavoritPage::class.java)) // Navigate to FavoritPage
            finish() // Finish current activity
        }

        navWrite.setOnClickListener {
            startActivity(Intent(this, RequestListActivity::class.java)) // Navigate to RequestListActivity
            finish() // Finish current activity
        }

        navProfile.setOnClickListener {
            startActivity(Intent(this, ProfilePage::class.java)) // Navigate to ProfilePage
            finish() // Finish current activity
        }

        navSearch.setOnClickListener {
            startActivity(Intent(this, Telusuri1page::class.java)) // Navigate to Telusuri1page
            finish() // Finish current activity
        }
    }
}
