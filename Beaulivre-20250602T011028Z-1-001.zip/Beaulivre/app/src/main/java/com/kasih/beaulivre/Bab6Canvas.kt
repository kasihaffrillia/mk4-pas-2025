package com.kasih.beaulivre

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Bab6Canvas : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_bab6_canvas)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Back ke Bab5Canvas
        findViewById<ImageButton>(R.id.btn_back).setOnClickListener {
            startActivity(Intent(this, Bab5Canvas::class.java))
            finish()
        }

        // Next ke Bab7Canvas
        findViewById<Button>(R.id.btn_next).setOnClickListener {
            startActivity(Intent(this, Bab7Canvas::class.java))
            finish()
        }

        setupBottomNavigation()
    }

    private fun setupBottomNavigation() {
        val navHome = findViewById<ImageView>(R.id.nav_home)
        val navDraft = findViewById<ImageView>(R.id.nav_draft)
        val navWrite = findViewById<ImageView>(R.id.nav_write)
        val navProfile = findViewById<ImageView>(R.id.nav_profile)
        val navSearch = findViewById<ImageView>(R.id.nav_search)

        navHome.setOnClickListener {
            startActivity(Intent(this, HomePage::class.java))
            finish()
        }
        navDraft.setOnClickListener {
            startActivity(Intent(this, FavoritPage::class.java))
            finish()
        }
        navWrite.setOnClickListener {
            startActivity(Intent(this, RequestListActivity::class.java))
            finish()
        }
        navProfile.setOnClickListener {
            startActivity(Intent(this, ProfilePage::class.java))
            finish()
        }
        navSearch.setOnClickListener {
            startActivity(Intent(this, Telusuri1page::class.java))
            finish()
        }
    }
}
